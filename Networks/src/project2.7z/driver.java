
public class driver {
	public static void main(String[] args)
	{
		String fName = "C:\\Users\\Syvirx\\OneDrive - University of Tulsa\\CS Labs\\Networks\\src\\text.txt";
		int mode = 0;
		long modeParam = 150;
		long timeout = 200;
		int lPort = 3344;
		RSendUDP.setFilename(fName);
		RSendUDP.setMode(mode);
		RSendUDP.setLocalPort(lPort);
		RSendUDP.setTimeout(timeout);
		RReceiveUDP.setFilename(fName);
		RReceiveUDP.setMode(mode);
		RReceiveUDP.setLocalPort(lPort);
		RSendUDP.sendFile();
		RReceiveUDP.receiveFile();
		
	}
}
