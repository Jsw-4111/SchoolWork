public interface RReceiveUDPI {
	public abstract boolean setMode(int mode);
	public abstract int getMode();
	public abstract boolean setModeParameter(long n);
	public abstract long getModeParameter();
	public abstract void setFilename(java.lang.String fname);
	public abstract java.lang.String getFilename();
	public abstract boolean setLocalPort(int port);
	public abstract int getLocalPort();
	public abstract boolean receiveFile();
}
