public interface RSendUDPI {

	public abstract boolean setMode(int mode);
	public abstract int getMode();
	public abstract boolean setModeParameter(long n);
	public abstract long getModeParameter();
	public abstract void setFilename(java.lang.String fname);
	public abstract java.lang.String getFilename();
	public abstract boolean setTimeout(long timeout);
	public abstract long getTimeout();
	public abstract boolean setLocalPort(int port);
	public abstract int getLocalPort();
	public abstract boolean setReceiver(java.net.InetSocketAddress receiver);
	public abstract java.net.InetSocketAddress getReceiver();
	public abstract boolean sendFile();
	
}
