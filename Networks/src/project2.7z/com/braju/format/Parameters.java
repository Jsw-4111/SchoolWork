package com.braju.format;

import java.util.Vector;

public class Parameters {
  private Vector a = new Vector();
  
  private boolean if = false;
  
  public Parameters() { this.a.addElement(new ParametersAutoClear()); }
  
  public Parameters(boolean paramBoolean) {
    this();
    add(paramBoolean);
  }
  
  public Parameters(char paramChar) {
    this();
    add(paramChar);
  }
  
  public Parameters(byte paramByte) {
    this();
    add(paramByte);
  }
  
  public Parameters(short paramShort) {
    this();
    add(paramShort);
  }
  
  public Parameters(int paramInt) {
    this();
    add(paramInt);
  }
  
  public Parameters(long paramLong) {
    this();
    add(paramLong);
  }
  
  public Parameters(float paramFloat) {
    this();
    add(paramFloat);
  }
  
  public Parameters(double paramDouble) {
    this();
    add(paramDouble);
  }
  
  public Parameters(String paramString) {
    this();
    add(paramString);
  }
  
  public Parameters(Object paramObject) {
    this();
    add(paramObject);
  }
  
  public Parameters(Vector paramVector) {}
  
  public Vector toVector() { return this.a; }
  
  public Parameters add(boolean paramBoolean) {
    this.a.addElement(new Boolean(paramBoolean));
    return this;
  }
  
  public Parameters add(char paramChar) {
    this.a.addElement(new Character(paramChar));
    return this;
  }
  
  public Parameters add(byte paramByte) {
    this.a.addElement(new Byte(paramByte));
    return this;
  }
  
  public Parameters add(short paramShort) {
    this.a.addElement(new Short(paramShort));
    return this;
  }
  
  public Parameters add(int paramInt) {
    this.a.addElement(new Integer(paramInt));
    return this;
  }
  
  public Parameters add(long paramLong) {
    this.a.addElement(new Long(paramLong));
    return this;
  }
  
  public Parameters add(float paramFloat) {
    this.a.addElement(new Float(paramFloat));
    return this;
  }
  
  public Parameters add(double paramDouble) {
    this.a.addElement(new Double(paramDouble));
    return this;
  }
  
  public Parameters add(String paramString) {
    this.a.addElement(paramString);
    return this;
  }
  
  public Parameters add(Object paramObject) {
    this.a.addElement(paramObject);
    return this;
  }
  
  public Parameters autoClear(boolean paramBoolean) {
    if (isAutoClear()) {
      if (!paramBoolean)
        this.a.removeElementAt(0); 
    } else if (paramBoolean) {
      this.a.insertElementAt(new ParametersAutoClear(), 0);
    } 
    return this;
  }
  
  public boolean isAutoClear() { return this.a.firstElement() instanceof ParametersAutoClear; }
  
  public Parameters clear() {
    if (isAutoClear()) {
      this.a.removeAllElements();
      autoClear(true);
    } else {
      this.a.removeAllElements();
    } 
    return this;
  }
}


/* Location:              C:\Users\Syvirx\Download\\unet.jar!\com\braju\format\Parameters.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */