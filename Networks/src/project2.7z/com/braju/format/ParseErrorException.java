package com.braju.format;

public class ParseErrorException extends RuntimeException {
  String a = new String("Unexpected character.");
  
  public ParseErrorException() {}
  
  public ParseErrorException(String paramString) {}
  
  public String toString() { return this.a; }
}


/* Location:              C:\Users\Syvirx\OneDrive - University of Tulsa\CS Labs\Networks\src\!\com\braju\format\ParseErrorException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */