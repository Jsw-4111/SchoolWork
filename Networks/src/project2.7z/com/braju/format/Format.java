package com.braju.format;

import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.Writer;
import java.util.Vector;

public class Format extends a {
  private static boolean long = true;
  
  private static Object null = new Object();
  
  private static final double void = Math.log(10.0D);
  
  public static void version() { System.out.println("Java printf package version " + getVersion()); }
  
  private static void a(c paramc, Object paramObject) {
    boolean bool = false;
    if (paramc.byte == 11) {
      bool = true;
    } else if (paramc.byte == 2 || paramc.byte == 3 || paramc.byte == 4 || paramc.byte == 1 || paramc.byte == 8 || paramc.byte == 6 || paramc.byte == 9) {
      bool = (paramObject instanceof Boolean || paramObject instanceof Character || paramObject instanceof Byte || paramObject instanceof Short || paramObject instanceof Integer || paramObject instanceof Long || paramObject instanceof Float || paramObject instanceof Double) ? 1 : 0;
    } else if (paramc.byte == 12) {
      bool = (paramObject instanceof Boolean || paramObject instanceof Byte || paramObject instanceof Short || paramObject instanceof Integer || paramObject instanceof Long) ? 1 : 0;
    } else if (paramc.byte == 13) {
      bool = (paramObject instanceof Boolean || paramObject instanceof Character || paramObject instanceof Byte || paramObject instanceof Short || paramObject instanceof Integer || paramObject instanceof Long) ? 1 : 0;
    } else if (paramc.byte == 14) {
      bool = (paramObject instanceof Byte || paramObject instanceof Short || paramObject instanceof Integer) ? 1 : 0;
    } 
    if (!bool) {
      String str = paramObject.getClass().getName();
      throw new ClassCastException("One of the arguments can not be casted to the necessary data type as required by one of the format flags: %" + paramc.a() + " != " + str + ".");
    } 
  }
  
  private static int a(c paramc) { return paramc.i ? 1 : 3; }
  
  private static boolean if(c paramc) { return (paramc.o == '0'); }
  
  private static int do(c paramc) { return paramc.long ? 8 : (paramc.p ? 12 : 4); }
  
  private static double if(Object paramObject) { return (paramObject instanceof Character) ? ((Character)paramObject).charValue() : ((Number)paramObject).doubleValue(); }
  
  private static long a(Object paramObject) { return (paramObject instanceof Character) ? ((Character)paramObject).charValue() : ((paramObject instanceof Boolean) ? (((Boolean)paramObject).booleanValue() ? 1L : 0L) : ((Number)paramObject).longValue()); }
  
  private static String a(Object paramObject, c paramc, boolean paramBoolean) {
    String str;
    double d = if(paramObject);
    if (paramc.m == Integer.MIN_VALUE)
      if (paramObject instanceof Float) {
        paramc.m = 6;
      } else if (paramObject instanceof Double) {
        paramc.m = 6;
      } else {
        paramc.m = 0;
      }  
    int i = a(paramc);
    if (paramBoolean || paramc.e) {
      if (paramc.e) {
        long l = (long)Math.abs(d);
        if (l != 0L)
          paramc.m = (int)(paramc.m - (long)(Math.log(l) / void)); 
      } 
      if (i == 1) {
        str = a.a(d, paramc.g, paramc.m, i, if(paramc), do(paramc));
      } else {
        str = a.a(d, paramc.g, paramc.m, i, if(paramc), do(paramc));
      } 
    } else {
      long l = (long)Math.abs(d);
      if (i == 1) {
        str = a.a(d, paramc.g, paramc.m, i, if(paramc), do(paramc));
      } else {
        str = a.a(d, paramc.g, paramc.m, i, if(paramc), do(paramc));
      } 
      int j = str.length() - 1;
      int k = j;
      char c1;
      for (c1 = str.charAt(k); c1 == '0'; c1 = str.charAt(--k));
      if (c1 == '.')
        k--; 
      if (k != j)
        str = str.substring(0, k + 1); 
      int m = paramc.g - str.length();
      if (m > 0) {
        String str1;
        for (str1 = ""; m-- > 0; str1 = str1 + " ");
        if (i == 1) {
          str = str + str1;
        } else {
          str = str1 + str;
        } 
      } 
    } 
    return str;
  }
  
  private static long a(double paramDouble) {
    long l;
    if (paramDouble < 0.0D) {
      l = (long)(Math.log(-paramDouble) / void);
      if (l < 0L) {
        l--;
      } else if (-1.0D < paramDouble && paramDouble < 0.0D) {
        l--;
      } 
    } else if (paramDouble > 0.0D) {
      l = (long)(Math.log(paramDouble) / void);
      if (l < 0L) {
        l--;
      } else if (0.0D < paramDouble && paramDouble < 1.0D) {
        l--;
      } 
    } else {
      l = 0L;
    } 
    return l;
  }
  
  private static double a(double paramDouble, long paramLong) { return paramDouble / Math.pow(10.0D, paramLong); }
  
  private static String do(Object paramObject, c paramc) {
    double d1 = if(paramObject);
    long l = a(d1);
    if (paramc.m == Integer.MIN_VALUE)
      if (paramObject instanceof Float) {
        paramc.m = 6;
      } else if (paramObject instanceof Double) {
        paramc.m = 6;
      } else {
        paramc.m = 0;
      }  
    double d2 = a(d1, l);
    double d3 = (d2 < 0.0D) ? -d2 : d2;
    if ((int)d3 == 9) {
      byte[] arrayOfByte = a.do(d3, paramc.m);
      if (a.a(arrayOfByte, paramc.m) > 0) {
        l++;
        d2 = a(d1, l);
      } 
      arrayOfByte = null;
    } else if ((int)d3 == 10) {
      d2 /= 10.0D;
      l++;
    } 
    return a(d2, l, paramc, true);
  }
  
  private static String a(double paramDouble, long paramLong, c paramc, boolean paramBoolean) {
    String str2;
    String str1 = String.valueOf(Math.abs(paramLong));
    int i = str1.length();
    if (i == 1) {
      str1 = "0" + str1;
      i = 2;
    } 
    if (paramLong < 0L) {
      str1 = "-" + str1;
    } else {
      str1 = "+" + str1;
    } 
    i++;
    str1 = "e" + str1;
    if (paramc.g >= ++i)
      paramc.g -= i; 
    int j = a(paramc);
    if (paramBoolean || paramc.e) {
      if (paramc.e)
        paramc.m--; 
      if (j != 1) {
        str2 = a.a(paramDouble, paramc.g, paramc.m, j, if(paramc), do(paramc));
        str2 = str2 + str1;
      } else {
        str2 = a.a(paramDouble, 0, paramc.m, j, if(paramc), do(paramc));
        int k = paramc.g - str2.length();
        for (str2 = str2 + str1; k-- > 0; str2 = str2 + " ");
      } 
    } else {
      if (j != 1) {
        str2 = a.a(paramDouble, paramc.g, paramc.m - 1, j, if(paramc), do(paramc));
      } else {
        str2 = a.a(paramDouble, 0, paramc.m - 1, j, if(paramc), do(paramc));
      } 
      int k = str2.length() - 1;
      int m = k;
      char c1;
      for (c1 = str2.charAt(m); c1 == '0'; c1 = str2.charAt(--m));
      if (c1 == '.')
        m--; 
      if (m != k)
        str2 = str2.substring(0, m + 1); 
      str2 = str2 + str1;
      int n = paramc.g + i - str2.length();
      if (n > 0) {
        String str;
        for (str = ""; n-- > 0; str = str + " ");
        if (j == 1) {
          str2 = str2 + str;
        } else {
          str2 = str + str2;
        } 
      } 
    } 
    return str2;
  }
  
  private static String for(Object paramObject, c paramc) {
    double d1 = if(paramObject);
    if (paramc.m == Integer.MIN_VALUE)
      if (paramObject instanceof Float) {
        paramc.m = 6;
      } else if (paramObject instanceof Double) {
        paramc.m = 6;
      } else {
        paramc.m = 0;
      }  
    long l = a(d1);
    double d2 = a(d1, l);
    double d3 = (d2 < 0.0D) ? -d2 : d2;
    if ((int)d3 == 9) {
      byte[] arrayOfByte = a.do(d3, paramc.m);
      if (a.a(arrayOfByte, paramc.m - 1) > 0) {
        l++;
        d2 = a(d1, l);
      } 
      arrayOfByte = null;
    } else if ((int)d3 == 10) {
      d2 /= 10.0D;
      l++;
    } 
    if (l < -4L || l >= paramc.m)
      return a(d2, l, paramc, false); 
    paramc.m = (int)(paramc.m - l + 1L);
    return a(paramObject, paramc, false);
  }
  
  private static String if(Object paramObject, c paramc) {
    long l;
    boolean bool = if(paramc);
    if (paramObject instanceof Character) {
      l = ((Character)paramObject).charValue();
      String str1 = Long.toHexString(l);
      if (l < 0L) {
        l &= 0xFFFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 16;
        } else {
          paramc.g = 18;
        } 
      } 
    } else if (paramObject instanceof Byte) {
      l = (byte)((Number)paramObject).intValue();
      if (l < 0L) {
        l &= 0xFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 8;
        } else {
          paramc.g = 10;
        } 
      } 
    } else if (paramObject instanceof Short) {
      l = (short)((Number)paramObject).intValue();
      if (l < 0L) {
        l &= 0xFFFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 16;
        } else {
          paramc.g = 18;
        } 
      } 
    } else if (paramObject instanceof Integer) {
      l = ((Integer)paramObject).intValue();
      if (l < 0L) {
        l &= 0xFFFFFFFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 32;
        } else {
          paramc.g = 34;
        } 
      } 
    } else {
      l = ((Number)paramObject).longValue();
      if (l >= 0L && bool && paramc.g == Integer.MIN_VALUE)
        if (!paramc.e) {
          paramc.g = 64;
        } else {
          paramc.g = 66;
        }  
    } 
    if (paramc.g == Integer.MIN_VALUE)
      paramc.g = 0; 
    if (paramc.m == Integer.MIN_VALUE)
      paramc.m = 0; 
    if (paramc.e) {
      paramc.m -= 2;
      if (paramc.g > 2)
        paramc.g -= 2; 
    } 
    String str = Long.toBinaryString(l);
    if (bool) {
      if (l < 0L) {
        str = a.a(str, paramc.g, 0, a(paramc), '1', ' ');
      } else {
        str = a.a(str, paramc.g, 0, a(paramc), '0', ' ');
      } 
    } else {
      str = a.a(str, paramc.g, 0, a(paramc), ' ', ' ');
    } 
    if (paramc.e)
      str = "0b" + str; 
    return str;
  }
  
  private static String new(Object paramObject, c paramc) {
    long l;
    boolean bool = if(paramc);
    if (paramObject instanceof Character) {
      l = ((Character)paramObject).charValue();
      String str1 = Long.toHexString(l);
      if (l < 0L) {
        l &= 0xFFFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 4;
        } else {
          paramc.g = 6;
        } 
      } 
    } else if (paramObject instanceof Byte) {
      l = (byte)((Number)paramObject).intValue();
      if (l < 0L) {
        l &= 0xFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 2;
        } else {
          paramc.g = 4;
        } 
      } 
    } else if (paramObject instanceof Short) {
      l = (short)((Number)paramObject).intValue();
      if (l < 0L) {
        l &= 0xFFFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 4;
        } else {
          paramc.g = 6;
        } 
      } 
    } else if (paramObject instanceof Integer) {
      l = ((Integer)paramObject).intValue();
      if (l < 0L) {
        l &= 0xFFFFFFFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 8;
        } else {
          paramc.g = 10;
        } 
      } 
    } else {
      l = ((Number)paramObject).longValue();
      if (l >= 0L && bool && paramc.g == Integer.MIN_VALUE)
        if (!paramc.e) {
          paramc.g = 16;
        } else {
          paramc.g = 18;
        }  
    } 
    if (paramc.g == Integer.MIN_VALUE)
      paramc.g = 0; 
    if (paramc.e) {
      paramc.m -= 2;
      if (paramc.g > 2)
        paramc.g -= 2; 
    } 
    String str = Long.toHexString(l);
    if (bool) {
      if (l < 0L) {
        str = a.a(str, paramc.g, 0, a(paramc), 'f', ' ');
      } else {
        str = a.a(str, paramc.g, 0, a(paramc), '0', ' ');
      } 
    } else {
      str = a.a(str, paramc.g, 0, a(paramc), ' ', ' ');
    } 
    if (paramc.e)
      str = "0x" + str; 
    return str;
  }
  
  private static String a(Object paramObject, c paramc) {
    long l;
    boolean bool = if(paramc);
    if (paramObject instanceof Character) {
      l = ((Character)paramObject).charValue();
      if (l < 0L) {
        l &= 0xFFFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 6;
        } else {
          paramc.g = 7;
        } 
      } 
    } else if (paramObject instanceof Byte) {
      l = (byte)((Number)paramObject).intValue();
      if (l < 0L) {
        l &= 0xFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 3;
        } else {
          paramc.g = 4;
        } 
      } 
    } else if (paramObject instanceof Short) {
      l = (short)((Number)paramObject).intValue();
      if (l < 0L) {
        l &= 0xFFFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 6;
        } else {
          paramc.g = 7;
        } 
      } 
    } else if (paramObject instanceof Integer) {
      l = ((Integer)paramObject).longValue();
      if (l < 0L) {
        l &= 0xFFFFFFFFL;
      } else if (bool && paramc.g == Integer.MIN_VALUE) {
        if (!paramc.e) {
          paramc.g = 11;
        } else {
          paramc.g = 12;
        } 
      } 
    } else {
      l = ((Long)paramObject).longValue();
      if (l >= 0L && bool && paramc.g == Integer.MIN_VALUE)
        if (!paramc.e) {
          paramc.g = 22;
        } else {
          paramc.g = 23;
        }  
    } 
    if (paramc.g == Integer.MIN_VALUE)
      paramc.g = 0; 
    if (paramc.e) {
      paramc.m--;
      if (paramc.g > 1)
        paramc.g--; 
    } 
    String str = Long.toOctalString(l);
    if (bool) {
      if (l < 0L) {
        str = a.a(str, paramc.g, 0, a(paramc), '7', ' ');
      } else {
        str = a.a(str, paramc.g, 0, a(paramc), '0', ' ');
      } 
    } else {
      str = a.a(str, paramc.g, 0, a(paramc), ' ', ' ');
    } 
    if (paramc.e)
      str = "0" + str; 
    return str;
  }
  
  private static String int(Object paramObject, c paramc) {
    long l;
    if (paramObject instanceof Character) {
      l = ((Character)paramObject).charValue();
    } else {
      l = ((Number)paramObject).longValue();
    } 
    if (l < 0L)
      l &= 0xFFFFL; 
    if (paramc.g == Integer.MIN_VALUE)
      paramc.g = 0; 
    null = Long.toHexString(l);
    int i = null.length();
    if (i > 4) {
      null = null.substring(i - 3);
    } else if (i < 4) {
      null = "0000".substring(4 - i) + null;
    } 
    null = "\\u" + null;
    return a.a(null, paramc.g, 0, a(paramc), paramc.o, paramc.o);
  }
  
  public static void setModifyLineSeparators(boolean paramBoolean) { long = paramBoolean; }
  
  public static boolean getModifyLineSeparators() { return long; }
  
  public static String sprintf(String paramString, Vector paramVector) throws ParseErrorException {
    synchronized (null) {
      String str = "";
      boolean bool = false;
      if (paramVector.size() > 0 && paramVector.firstElement() instanceof ParametersAutoClear) {
        bool = true;
        paramVector.removeElementAt(0);
      } 
      b b = new b(paramString);
      b.else();
      Vector vector1 = b.byte();
      for (byte b1 = 0; b1 < vector1.size(); b1++) {
        c c = (c)vector1.elementAt(b1);
        Object object = paramVector.elementAt(b1);
        if (c.g == -1) {
          c.g = ((Number)object).intValue();
          if (c.g < 0) {
            c.i = true;
            c.g = -c.g;
          } 
          paramVector.removeElementAt(b1);
        } 
        object = paramVector.elementAt(b1);
        if (c.m == -1) {
          c.m = ((Number)object).intValue();
          paramVector.removeElementAt(b1);
        } 
      } 
      Vector vector2 = b.char();
      for (byte b2 = 0; b2 < vector1.size(); b2++) {
        c c = (c)vector1.elementAt(b2);
        int i = a(c);
        boolean bool1 = if(c);
        int j = do(c);
        String str2 = (String)vector2.elementAt(b2);
        Object object = paramVector.elementAt(b2);
        a(c, object);
        str = str + str2;
        String str1 = "";
        if (c.byte == 11) {
          if (c.g == Integer.MIN_VALUE)
            c.g = 0; 
          if (c.m == Integer.MIN_VALUE)
            c.m = 0; 
          if (object == null) {
            str1 = a.a("null", c.g, c.m, a(c), c.o, c.o);
          } else if (object instanceof String) {
            str1 = a.a((String)object, c.g, c.m, a(c), c.o, c.o);
          } else {
            str1 = a.a(object.toString(), c.g, c.m, a(c), c.o, c.o);
          } 
        } else if (c.byte == 12) {
          boolean bool2;
          if (object instanceof Boolean) {
            bool2 = ((Boolean)object).booleanValue();
          } else {
            bool2 = (((Number)object).longValue() != 0L);
          } 
          if (c.g == Integer.MIN_VALUE)
            c.g = 0; 
          if (c.m == Integer.MIN_VALUE)
            c.m = 0; 
          str1 = a.a(bool2, c.g, a(c), c.m);
        } else if (c.byte == 1) {
          char c1;
          if (object instanceof Character) {
            c1 = ((Character)object).charValue();
          } else {
            c1 = (char)((Number)object).intValue();
          } 
          if (c.m == Integer.MIN_VALUE)
            c.m = 0; 
          if (!c.e) {
            if (c.g == Integer.MIN_VALUE)
              c.g = 0; 
            str1 = a.a(c1, c.g, a(c), c.o, c.o);
          } else {
            str1 = int(object, c);
          } 
        } else if (c.byte == 2) {
          long l;
          if (object instanceof Character) {
            l = ((Character)object).charValue();
          } else {
            l = ((Number)object).longValue();
          } 
          if (c.g == Integer.MIN_VALUE)
            c.g = 0; 
          if (c.m == Integer.MIN_VALUE)
            c.m = 0; 
          str1 = a.a(l, c.g, a(c), if(c), do(c));
        } else if (c.byte == 13) {
          str1 = if(object, c);
        } else if (c.byte == 4) {
          if (c.m == Integer.MIN_VALUE)
            c.m = 0; 
          str1 = new(object, c);
        } else if (c.byte == 3) {
          if (c.m == Integer.MIN_VALUE)
            c.m = 0; 
          str1 = a(object, c);
        } else if (c.byte == 8) {
          if (c.g == Integer.MIN_VALUE)
            c.g = 0; 
          str1 = a(object, c, true);
        } else if (c.byte == 6) {
          if (c.g == Integer.MIN_VALUE)
            c.g = 0; 
          str1 = do(object, c);
        } else if (c.byte == 9) {
          if (c.g == Integer.MIN_VALUE)
            c.g = 0; 
          str1 = for(object, c);
        } else if (c.byte == 14) {
          long l;
          if (object instanceof Character) {
            l = ((Character)object).charValue();
          } else if (object instanceof Byte) {
            l = ((Byte)object).longValue();
            if (l < 0L)
              l += 256L; 
          } else if (object instanceof Short) {
            l = ((Short)object).longValue();
            if (l < 0L)
              l += 65536L; 
          } else if (object instanceof Integer) {
            l = ((Integer)object).longValue();
            if (l < 0L)
              l += 4294967296L; 
          } else {
            if (object instanceof Long) {
              long l1 = ((Long)object).longValue();
              throw new ClassCastException("Convertion of a long into an unsigned long is not supported: " + l1 + "l");
            } 
            l = ((Number)object).intValue();
            if (l < 0L)
              l += 4294967296L; 
          } 
          if (c.g == Integer.MIN_VALUE)
            c.g = 0; 
          if (c.m == Integer.MIN_VALUE)
            c.m = 0; 
          str1 = a.a(l, c.g, a(c), if(c), do(c));
        } else {
          System.err.println("sprintf(): Unknown type " + c.a());
        } 
        if (c.else == 2)
          str1 = str1.toUpperCase(); 
        str = str + str1;
      } 
      str = str + (String)vector2.lastElement();
      if (paramVector.size() > 0 && paramVector.firstElement() instanceof ParametersAutoClear)
        paramVector.removeAllElements(); 
      if (bool) {
        paramVector.removeAllElements();
        paramVector.addElement(new ParametersAutoClear());
      } 
      if (long)
        str = a.a(str); 
      return str.toString();
    } 
  }
  
  public static String sprintf(String paramString, Object[] paramArrayOfObject) throws ParseErrorException {
    Vector vector = new Vector();
    for (byte b = 0; b < paramArrayOfObject.length; b++)
      vector.addElement(paramArrayOfObject[b]); 
    String str = sprintf(paramString, vector);
    vector.removeAllElements();
    vector = null;
    return str;
  }
  
  public static String sprintf(String paramString, Parameters paramParameters) throws ParseErrorException { return sprintf(paramString, paramParameters.toVector()); }
  
  public static void fprintf(OutputStream paramOutputStream, String paramString, Vector paramVector) throws IOException, ParseErrorException {
    StringReader stringReader = new StringReader(sprintf(paramString, paramVector));
    for (int i = stringReader.read(); i != -1; i = stringReader.read())
      paramOutputStream.write(i); 
    paramOutputStream.flush();
    stringReader.close();
  }
  
  public static void fprintf(OutputStream paramOutputStream, String paramString, Parameters paramParameters) throws IOException, ParseErrorException { fprintf(paramOutputStream, paramString, paramParameters.toVector()); }
  
  public static void fprintf(OutputStream paramOutputStream, String paramString, Object[] paramArrayOfObject) throws IOException, ParseErrorException {
    StringReader stringReader = new StringReader(sprintf(paramString, paramArrayOfObject));
    for (int i = stringReader.read(); i != -1; i = stringReader.read())
      paramOutputStream.write(i); 
    paramOutputStream.flush();
    stringReader.close();
  }
  
  public static void fprintf(OutputStream paramOutputStream, String paramString) throws IOException, ParseErrorException { fprintf(paramOutputStream, paramString, new Vector()); }
  
  public static void printf(String paramString, Vector paramVector) throws ParseErrorException { System.out.print(sprintf(paramString, paramVector)); }
  
  public static void printf(String paramString, Parameters paramParameters) throws ParseErrorException { System.out.print(sprintf(paramString, paramParameters)); }
  
  public static void printf(String paramString, Object[] paramArrayOfObject) throws ParseErrorException { System.out.print(sprintf(paramString, paramArrayOfObject)); }
  
  public static void printf(String paramString) throws ParseErrorException { printf(paramString, new Vector()); }
  
  public static void fprintf(Writer paramWriter, String paramString, Vector paramVector) throws IOException, ParseErrorException {
    StringReader stringReader = new StringReader(sprintf(paramString, paramVector));
    for (int i = stringReader.read(); i != -1; i = stringReader.read())
      paramWriter.write(i); 
    paramWriter.flush();
    stringReader.close();
  }
  
  public static void fprintf(Writer paramWriter, String paramString, Object[] paramArrayOfObject) throws IOException, ParseErrorException {
    StringReader stringReader = new StringReader(sprintf(paramString, paramArrayOfObject));
    for (int i = stringReader.read(); i != -1; i = stringReader.read())
      paramWriter.write(i); 
    paramWriter.flush();
    stringReader.close();
  }
  
  public static void fprintf(Writer paramWriter, String paramString, Parameters paramParameters) throws IOException, ParseErrorException { fprintf(paramWriter, paramString, paramParameters.toVector()); }
  
  public static void fprintf(Writer paramWriter, String paramString) throws IOException, ParseErrorException { fprintf(paramWriter, paramString, new Vector()); }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    if (paramArrayOfString.length == 0 || paramArrayOfString[0].equals("-help")) {
      System.out.println(if());
    } else if (paramArrayOfString[0].equals("-printf")) {
      byte b = 1;
      printf(paramArrayOfString[b], a(paramArrayOfString, b));
    } else if (paramArrayOfString[0].equals("-version")) {
      version();
    } 
  }
  
  protected static Parameters a(String[] paramArrayOfString, int paramInt) throws Exception {
    Parameters parameters = new Parameters();
    b b = new b(paramArrayOfString[paramInt]);
    b.else();
    Vector vector = b.byte();
    for (int i = 0; i < vector.size(); i++) {
      c c = (c)vector.elementAt(i);
      String str = paramArrayOfString[i + paramInt + 1];
      if (c.g == -1) {
        parameters.add(Long.valueOf(str));
        paramInt++;
      } 
      if (c.m == -1) {
        parameters.add(Long.valueOf(str));
        paramInt++;
      } 
      if (c.byte == 12) {
        try {
          parameters.add(Integer.valueOf(str));
        } catch (NumberFormatException numberFormatException) {
          parameters.add(Boolean.valueOf(str));
        } 
      } else if (c.byte == 1) {
        try {
          if (str.length() != 1) {
            parameters.add(Double.valueOf(str));
          } else {
            parameters.add(str.charAt(0));
          } 
        } catch (NumberFormatException numberFormatException) {
          parameters.add(str.charAt(0));
        } 
      } else if (c.byte == 4 || c.byte == 3 || c.byte == 13) {
        parameters.add(Long.valueOf(str));
      } else if (c.byte == 8 || c.byte == 6 || c.byte == 9) {
        parameters.add(Double.valueOf(str));
      } else if (c.byte == 2 || c.byte == 14) {
        int j = str.length();
        char c1 = str.charAt(j - 1);
        try {
          str = str.substring(0, j - 1);
          if (c1 == 'b') {
            parameters.add(Byte.valueOf(str));
          } else if (c1 == 's') {
            parameters.add(Short.valueOf(str));
          } else if (c1 == 'i') {
            parameters.add(Integer.valueOf(str));
          } else if (c1 == 'l') {
            parameters.add(Long.valueOf(str));
          } else {
            str = str + c1;
            try {
              parameters.add(Integer.valueOf(str));
            } catch (NumberFormatException numberFormatException) {
              parameters.add(Long.valueOf(str));
            } 
          } 
        } catch (NumberFormatException numberFormatException) {
          try {
            parameters.add(Long.valueOf(str));
          } catch (NumberFormatException numberFormatException1) {
            parameters.add(Double.valueOf(str));
          } 
        } 
      } else {
        parameters.add(str);
      } 
    } 
    return parameters;
  }
  
  public static String getVersion() { return "1.6"; }
  
  protected static String if() { return "Java printf version " + getVersion() + " by Henrik Bengtsson. Copyright 1997-2003\n" + "\n" + "Usage:\n" + " java com.braju.format.Format [-help|-version|-printf fmtstr [param]*]\n" + "\n" + "Options:\n" + " -help    Print this message.\n" + " -printf  Using the next argument (fmtstr) as the format string and\n" + "          one or more optional parameters (param) as values to be\n" + "          formatted by the printf method.\n" + " -version Print version information.\n" + "\n" + "Example:\n" + " java com.braju.format.Format -printf \"Yeah, %d%% %s.\" 100 Java\n" + "prints\n" + " Yeah, 100% Java.\n" + "\n" + "For more information see www.braju.com.\n"; }
}


/* Location:              C:\Users\Syvirx\Download\\unet.jar!\com\braju\format\Format.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */