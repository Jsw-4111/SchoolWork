package com.braju.format;

class c {
  public int byte = 0;
  
  public int g = Integer.MIN_VALUE;
  
  public int m = Integer.MIN_VALUE;
  
  public int else = 0;
  
  public char o = ' ';
  
  public boolean i = false;
  
  public boolean long = false;
  
  public boolean p = false;
  
  public boolean e = false;
  
  public boolean goto = false;
  
  public static final int new = 0;
  
  public static final int void = 1;
  
  public static final int u = 2;
  
  public static final int r = 3;
  
  public static final int d = 4;
  
  public static final int int = 6;
  
  public static final int s = 8;
  
  public static final int f = 9;
  
  public static final int for = 11;
  
  public static final int k = 12;
  
  public static final int do = 13;
  
  public static final int case = 14;
  
  public static final int j = 0;
  
  public static final int char = 1;
  
  public static final int if = 2;
  
  public static final int n = -2147483648;
  
  public static final int a = -1;
  
  public static final int try = 0;
  
  public static final int c = -2147483648;
  
  public static final int h = -1;
  
  public static final int b = 0;
  
  public static final int q = 0;
  
  public static final int t = 1;
  
  public static final int null = 2;
  
  public static final int l = 3;
  
  public String a() {
    String str;
    switch (this.byte) {
      case 0:
        str = "unknown";
        break;
      case 1:
        str = "c";
        break;
      case 2:
        str = "d";
        break;
      case 14:
        str = "u";
        break;
      case 3:
        str = "o";
        break;
      case 4:
        str = "x";
        break;
      case 6:
        str = "e";
        break;
      case 8:
        str = "f";
        break;
      case 9:
        str = "g";
        break;
      case 11:
        str = "s";
        break;
      case 12:
        str = "l";
        break;
      case 13:
        str = "b";
        break;
      default:
        str = "error";
        break;
    } 
    if (this.else == 2)
      str = str.toUpperCase(); 
    return str;
  }
  
  public String if() {
    switch (this.g) {
      case -2147483648:
        return "UNSPECIFIED";
      case -1:
        return "*";
      case 0:
        return "DEFAULT";
    } 
    return String.valueOf(this.g);
  }
  
  public String do() {
    switch (this.m) {
      case -2147483648:
        return "UNSPECIFIED";
      case -1:
        return "*";
      case 0:
        return "DEFAULT";
    } 
    return String.valueOf(this.m);
  }
  
  public String toString() { return new String("type=" + a() + ", minWidth=" + if() + ", precision=" + do()); }
}


/* Location:              C:\Users\Syvirx\OneDrive - University of Tulsa\CS Labs\Networks\src\!\com\braju\format\c.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */