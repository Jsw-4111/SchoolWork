package com.braju.format;

import java.util.Vector;

class b {
  private char[] a;
  
  private int new;
  
  c if;
  
  Vector int;
  
  Vector for;
  
  boolean do;
  
  public b(String paramString) {
    this.a = paramString.toCharArray();
    this.new = 0;
    this.int = new Vector();
    this.for = new Vector();
  }
  
  public Vector byte() { return this.int; }
  
  public Vector char() { return this.for; }
  
  public void else() throws ParseErrorException {
    String str = new String();
    for (boolean bool = false; !bool; bool = true) {
      if (a(37)) {
        if (a(37)) {
          str = str + '%';
          continue;
        } 
        this.if = new c();
        null();
        if (!this.do) {
          this.int.addElement(this.if);
          this.for.addElement(str);
          str = new String();
          this.if = null;
        } 
        continue;
      } 
      if (this.new < this.a.length) {
        str = str + this.a[this.new++];
        continue;
      } 
      this.for.addElement(str);
    } 
  }
  
  private void for() throws ParseErrorException {
    this.do = true;
    throw new ParseErrorException("Parse error. Unknown symbol: " + this.a[this.new]);
  }
  
  private void long() throws ParseErrorException {}
  
  private void null() throws ParseErrorException {
    this;
    this.if.m = Integer.MIN_VALUE;
    this.do = false;
    if (new()) {
      try();
    } else if (goto()) {
      void();
    } else if (a(46)) {
      case();
    } else if (int()) {
      long();
    } else {
      for();
    } 
  }
  
  private void try() throws ParseErrorException {
    if (new()) {
      try();
    } else if (goto()) {
      void();
    } else if (a(46)) {
      case();
    } else if (int()) {
      long();
    } else {
      for();
    } 
  }
  
  private void void() throws ParseErrorException {
    if (a(46)) {
      case();
    } else if (int()) {
      long();
    } else {
      for();
    } 
  }
  
  private void if() throws ParseErrorException {
    if (int()) {
      long();
    } else {
      for();
    } 
  }
  
  private void case() throws ParseErrorException {
    if (do()) {
      if();
    } else if (int()) {
      long();
    } else {
      for();
    } 
  }
  
  private int a() {
    if (this.new == this.a.length)
      return -1; 
    int i = -1;
    for (boolean bool = false; !bool; bool = true) {
      if (Character.isDigit(this.a[this.new])) {
        if (this.new == this.a.length)
          i = 0; 
        if (i == -1) {
          i = this.a[this.new] - '0';
        } else {
          i = 10 * i + this.a[this.new] - '0';
        } 
        if (++this.new == this.a.length)
          bool = true; 
        continue;
      } 
    } 
    return i;
  }
  
  private boolean goto() {
    if (a(42)) {
      this;
      this.if.g = -1;
      return true;
    } 
    int i = a();
    if (i != -1) {
      this.if.g = i;
      return true;
    } 
    return false;
  }
  
  private boolean do() {
    if (a(42)) {
      this;
      this.if.m = -1;
      return true;
    } 
    int i = a();
    if (i != -1) {
      this.if.m = i;
      return true;
    } 
    return false;
  }
  
  private boolean a(int paramInt) {
    if (this.new < this.a.length && this.a[this.new] == paramInt) {
      this.new++;
      return true;
    } 
    return false;
  }
  
  private boolean new() {
    boolean bool = true;
    if (a(48)) {
      this.if.o = '0';
    } else if (a(43)) {
      this.if.long = true;
    } else if (a(45)) {
      this.if.i = true;
    } else if (a(32)) {
      this.if.p = true;
    } else if (a(35)) {
      this.if.e = true;
    } else if (a(39)) {
      this.if.goto = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private boolean int() {
    boolean bool = true;
    if (a(99)) {
      this.if.byte = 1;
    } else if (a(100) || a(105)) {
      this.if.byte = 2;
    } else if (a(117)) {
      this.if.byte = 14;
    } else if (a(111)) {
      this.if.byte = 3;
    } else if (a(120)) {
      this.if.byte = 4;
      this.if.else = 1;
    } else if (a(88)) {
      this.if.byte = 4;
      this.if.else = 2;
    } else if (a(101)) {
      this.if.byte = 6;
      this.if.else = 1;
    } else if (a(69)) {
      this.if.byte = 6;
      this.if.else = 2;
    } else if (a(102)) {
      this.if.byte = 8;
    } else if (a(103)) {
      this.if.byte = 9;
      this.if.else = 1;
    } else if (a(71)) {
      this.if.byte = 9;
      this.if.else = 2;
    } else if (a(115)) {
      this.if.byte = 11;
    } else if (a(108)) {
      this.if.byte = 12;
      this.if.else = 1;
    } else if (a(76)) {
      this.if.byte = 12;
      this.if.else = 2;
    } else if (a(98)) {
      this.if.byte = 13;
      this.if.else = 1;
    } else if (a(66)) {
      this.if.byte = 13;
      this.if.else = 2;
    } else {
      bool = false;
    } 
    return bool;
  }
}


/* Location:              C:\Users\Syvirx\OneDrive - University of Tulsa\CS Labs\Networks\src\!\com\braju\format\b.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */