package com.braju.format;

class a {
  protected static final int char = 0;
  
  protected static final int a = 1;
  
  protected static final int if = 2;
  
  protected static final int byte = 3;
  
  protected static int for = 0;
  
  public static final int goto = 0;
  
  public static final int new = 1;
  
  public static final int else = 2;
  
  public static final int int = 3;
  
  public static final int try = 4;
  
  public static final int case = 8;
  
  public static final int do = 12;
  
  private static void a() {
    try {
      String str = System.getProperties().getProperty("line.separator");
      if (str.length() == 1) {
        if (str.charAt(0) == '\r') {
          for = 1;
        } else {
          for = 2;
        } 
      } else {
        for = 3;
      } 
    } catch (SecurityException securityException) {
      for = 2;
    } 
  }
  
  protected static String a(String paramString) {
    if (for == 2)
      return paramString; 
    if (for == 1) {
      StringBuffer stringBuffer = new StringBuffer(paramString);
      for (byte b = 0; b < stringBuffer.length(); b++) {
        if (stringBuffer.charAt(b) == '\n')
          stringBuffer.setCharAt(b, '\r'); 
      } 
      return stringBuffer.toString();
    } 
    if (for == 3) {
      StringBuffer stringBuffer = new StringBuffer(paramString);
      for (byte b = 0; b < stringBuffer.length(); b++) {
        char c = stringBuffer.charAt(b);
        if (c == '\n')
          stringBuffer.insert(b++, '\r'); 
        if (c == '\r' && (++b == stringBuffer.length() || stringBuffer.charAt(b) != '\n'))
          stringBuffer.insert(b, '\n'); 
      } 
      return stringBuffer.toString();
    } 
    a();
    return a(paramString);
  }
  
  private static String a(int paramInt, char paramChar) {
    String str = new String();
    while (paramInt > 0) {
      str = str + paramChar;
      paramInt--;
    } 
    return str;
  }
  
  private static boolean if(int paramInt) { return (paramInt == 3 || paramInt == 1 || paramInt == 2); }
  
  private static boolean a(int paramInt) { return (paramInt == 4 || paramInt == 8 || paramInt == 12); }
  
  public static String a(String paramString, int paramInt1, int paramInt2, int paramInt3, char paramChar1, char paramChar2) {
    String str;
    if (paramString == null || paramInt1 < 0 || paramInt2 < 0 || !if(paramInt3))
      return null; 
    if (paramInt2 > 0) {
      int j = paramString.length();
      if (paramInt2 > j)
        paramInt2 = j; 
      str = paramString.substring(0, paramInt2);
    } else {
      str = new String(paramString);
    } 
    int i = str.length();
    if (paramInt1 > i) {
      int j = paramInt1 - i;
      if (paramInt3 == 1) {
        str = str + a(j, paramChar2);
      } else if (paramInt3 == 3) {
        str = a(j, paramChar1) + str;
      } else if (paramInt3 == 2) {
        int k = j / 2;
        int m = j - k;
        str = a(k, paramChar1) + str + a(m, paramChar2);
      } 
    } 
    return str;
  }
  
  public static String a(char paramChar1, int paramInt1, int paramInt2, char paramChar2, char paramChar3) { return (paramInt1 < 0 || !if(paramInt2)) ? null : a(String.valueOf(paramChar1), paramInt1, 0, paramInt2, paramChar2, paramChar3); }
  
  private static char a(long paramLong, int paramInt) {
    char c = Character.MIN_VALUE;
    if (paramLong >= 0L) {
      if (paramInt == 8) {
        c = '+';
      } else if (paramInt == 12) {
        c = ' ';
      } 
    } else if (paramLong < 0L) {
      c = '-';
    } 
    return c;
  }
  
  private static char a(double paramDouble, int paramInt) {
    char c = Character.MIN_VALUE;
    if (paramDouble >= 0.0D) {
      if (paramInt == 8) {
        c = '+';
      } else if (paramInt == 12) {
        c = ' ';
      } 
    } else if (paramDouble < 0.0D) {
      c = '-';
    } 
    return c;
  }
  
  private static char a(int paramInt1, int paramInt2) { return a(paramInt1, paramInt2); }
  
  public static String a(long paramLong, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3) {
    String str;
    if (paramInt1 < 0 || !if(paramInt2) || !a(paramInt3))
      return null; 
    if (paramLong < 0L) {
      if (paramLong == Float.MIN_VALUE) {
        str = String.valueOf(paramLong).substring(1);
      } else {
        str = String.valueOf(-paramLong);
      } 
    } else {
      str = String.valueOf(paramLong);
    } 
    char c = a(paramLong, paramInt3);
    if (paramBoolean) {
      if (c != '\000') {
        if (paramInt1 > 0)
          paramInt1--; 
        str = c + a(str, paramInt1, 0, paramInt2, '0', ' ');
      } else {
        str = a(str, paramInt1, 0, paramInt2, '0', ' ');
      } 
    } else if (c != '\000') {
      str = a(c + str, paramInt1, 0, paramInt2, ' ', ' ');
    } else {
      str = a(str, paramInt1, 0, paramInt2, ' ', ' ');
    } 
    return str;
  }
  
  public static String a(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4) { return a(paramInt1, paramInt2, paramInt3, paramBoolean, paramInt4); }
  
  public static String a(double paramDouble, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4) {
    String str;
    if (paramInt1 < 0 || paramInt2 < 0 || !if(paramInt3) || !a(paramInt4))
      return null; 
    if (paramDouble < 0.0D) {
      str = if(-paramDouble, paramInt2);
    } else {
      str = if(paramDouble, paramInt2);
    } 
    char c = a(paramDouble, paramInt4);
    if (paramBoolean) {
      if (c != '\000') {
        if (paramInt1 > 0)
          paramInt1--; 
        str = c + a(str, paramInt1, 0, paramInt3, '0', ' ');
      } else {
        str = a(str, paramInt1, 0, paramInt3, '0', ' ');
      } 
    } else if (c != '\000') {
      str = a(c + str, paramInt1, 0, paramInt3, ' ', ' ');
    } else {
      str = a(str, paramInt1, 0, paramInt3, ' ', ' ');
    } 
    return str;
  }
  
  protected static byte[] do(double paramDouble, int paramInt) {
    byte[] arrayOfByte = new byte[paramInt + 1];
    long l1 = 1L;
    long l2 = 10L * (long)paramDouble;
    for (byte b = 0; b <= paramInt; b++) {
      l1 *= 10L;
      byte b1 = (byte)(int)(paramDouble * l1 - l2);
      if (b1 == 10) {
        arrayOfByte[b] = 0;
        l2 += 10L;
        byte b2 = b - true;
        arrayOfByte[b2] = (byte)(arrayOfByte[b2] + 1);
        while ((byte)(arrayOfByte[b2] + 1) == 10)
          arrayOfByte[b2--] = 0; 
      } else {
        arrayOfByte[b] = b1;
      } 
      l2 = 10L * (l2 + arrayOfByte[b]);
    } 
    return arrayOfByte;
  }
  
  protected static int a(byte[] paramArrayOfByte, int paramInt) {
    if (paramArrayOfByte[paramInt] >= 5) {
      if (paramInt == 0)
        return 1; 
      paramArrayOfByte[paramInt - 1] = (byte)(paramArrayOfByte[paramInt - 1] + 1);
      for (int i = paramInt - 1; i > 0; i--) {
        if (paramArrayOfByte[i] == 10) {
          paramArrayOfByte[i] = 0;
          paramArrayOfByte[i - 1] = (byte)(paramArrayOfByte[i - 1] + 1);
        } 
      } 
      if (paramArrayOfByte[0] == 10) {
        paramArrayOfByte[0] = 0;
        return 1;
      } 
    } 
    return 0;
  }
  
  protected static String if(double paramDouble, int paramInt) {
    long l2 = 1L;
    boolean bool = (paramDouble < 0.0D) ? 1 : 0;
    if (bool)
      paramDouble = -paramDouble; 
    long l1 = (long)paramDouble;
    byte[] arrayOfByte = do(paramDouble, paramInt);
    l1 += a(arrayOfByte, paramInt);
    StringBuffer stringBuffer = new StringBuffer();
    if (bool)
      stringBuffer.append('-'); 
    stringBuffer.append(String.valueOf(l1));
    stringBuffer.append('.');
    for (byte b = 0; b < paramInt; b++)
      stringBuffer.append(String.valueOf(arrayOfByte[b])); 
    return stringBuffer.toString();
  }
  
  public static String a(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 < 0 || !if(paramInt2))
      return null; 
    if (paramBoolean) {
      null = "true";
    } else {
      null = "false";
    } 
    return a(null, paramInt1, paramInt3, paramInt2, ' ', ' ');
  }
}


/* Location:              C:\Users\Syvirx\OneDrive - University of Tulsa\CS Labs\Networks\src\!\com\braju\format\a.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */