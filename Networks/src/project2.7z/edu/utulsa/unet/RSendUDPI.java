package edu.utulsa.unet;

import java.net.InetSocketAddress;

public interface RSendUDPI {
  boolean setMode(int paramInt);
  
  int getMode();
  
  boolean setModeParameter(long paramLong);
  
  long getModeParameter();
  
  void setFilename(String paramString);
  
  String getFilename();
  
  boolean setTimeout(long paramLong);
  
  long getTimeout();
  
  boolean setLocalPort(int paramInt);
  
  int getLocalPort();
  
  boolean setReceiver(InetSocketAddress paramInetSocketAddress);
  
  InetSocketAddress getReceiver();
  
  boolean sendFile();
}


/* Location:              C:\Users\Syvirx\OneDrive - University of Tulsa\CS Labs\Networks\src\!\ed\\utuls\\unet\RSendUDPI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */