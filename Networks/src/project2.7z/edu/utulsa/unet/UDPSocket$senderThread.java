/*     */ package edu.utulsa.unet;
/*     */ 
/*     */ import java.net.DatagramPacket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class senderThread
/*     */   extends Thread
/*     */ {
/*     */   UDPSocket socket;
/*     */   DatagramPacket packet;
/*     */   long id;
/*     */   boolean drop;
/*     */   
/*     */   senderThread(UDPSocket paramUDPSocket2, DatagramPacket paramDatagramPacket, long paramLong, boolean paramBoolean) {
/* 147 */     this.socket = paramUDPSocket2;
/* 148 */     this.packet = new DatagramPacket(paramDatagramPacket.getData(), paramDatagramPacket.getLength(), paramDatagramPacket.getAddress(), paramDatagramPacket.getPort());
/* 149 */     this.id = paramLong;
/* 150 */     this.drop = paramBoolean;
/* 151 */     start();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/* 158 */       sleep((long)(UDPSocket.access$000(UDPSocket.this) + UDPSocket.access$100(UDPSocket.this).nextFloat() * (UDPSocket.access$200(UDPSocket.this) - UDPSocket.access$000(UDPSocket.this))));
/*     */       
/*     */       try {
/* 161 */         if (!this.drop) UDPSocket.access$300(this.socket, this.packet); 
/* 162 */         UDPSocket.access$400(this.packet, this.id, this.drop);
/*     */       }
/* 164 */       catch (Exception exception) {
/*     */         
/* 166 */         exception.printStackTrace();
/*     */       }
/*     */     
/* 169 */     } catch (InterruptedException interruptedException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Syvirx\OneDrive - University of Tulsa\CS Labs\Networks\src\!\ed\\utuls\\unet\UDPSocket$senderThread.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */