/*     */ package edu.utulsa.unet;
/*     */ 
/*     */ import com.braju.format.Format;
/*     */ import com.braju.format.Parameters;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.DatagramSocketImpl;
/*     */ import java.net.InetAddress;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.SocketException;
/*     */ import java.util.Properties;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class UDPSocket
/*     */   extends DatagramSocket {
/*  19 */   private static int VER = 256;
/*  20 */   private static String PROP = "unet.properties";
/*  21 */   private static PrintStream logger = null;
/*  22 */   private static long start_time = System.currentTimeMillis();
/*     */   
/*  24 */   private int packet_mtu = 1500;
/*  25 */   private float packet_droprate = 0.0F;
/*  26 */   private int[] packet_drop = new int[0];
/*  27 */   private int packet_delay_min = 10;
/*  28 */   private int packet_delay_max = 10;
/*  29 */   private Random rand = new Random(System.currentTimeMillis());
/*     */   
/*  31 */   private long packet_counter = 1L;
/*     */ 
/*     */   
/*     */   public UDPSocket(SocketAddress paramSocketAddress) throws SocketException {
/*  35 */     super(paramSocketAddress);
/*  36 */     loadProperties();
/*     */   }
/*     */ 
/*     */   
/*     */   public UDPSocket(int paramInt, InetAddress paramInetAddress) throws SocketException {
/*  41 */     super(paramInt, paramInetAddress);
/*  42 */     loadProperties();
/*     */   }
/*     */ 
/*     */   
/*     */   public UDPSocket(DatagramSocketImpl paramDatagramSocketImpl) throws SocketException {
/*  47 */     super(paramDatagramSocketImpl);
/*  48 */     loadProperties();
/*     */   }
/*     */ 
/*     */   
/*     */   public UDPSocket(int paramInt) throws SocketException {
/*  53 */     super(paramInt);
/*  54 */     loadProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public UDPSocket() throws SocketException { loadProperties(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public int getSendBufferSize() throws SocketException { return this.packet_mtu; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public void setSendBufferSize(int paramInt) throws SocketException { throw new SocketException("MTU is adjusted within the unet.properties file"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private void rawSend(DatagramPacket paramDatagramPacket) throws IOException { super.send(paramDatagramPacket); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(DatagramPacket paramDatagramPacket) throws IOException {
/*  82 */     synchronized (paramDatagramPacket) {
/*  83 */       if (paramDatagramPacket.getLength() > this.packet_mtu) throw new IOException("Packet length exceeds MTU");
/*     */       
/*  85 */       boolean bool = ((this.packet_droprate < 0.0D && this.rand.nextFloat() <= this.packet_droprate * -1.0F) || (this.packet_droprate > 0.0D && (float)this.packet_counter % this.packet_droprate == 0.0F));
/*     */ 
/*     */ 
/*     */       
/*  89 */       for (byte b = 0; b < this.packet_drop.length; b++) {
/*  90 */         if (this.packet_counter - 1L == this.packet_drop[b])
/*  91 */           bool = true; 
/*     */       } 
/*  93 */       new senderThread(this, paramDatagramPacket, this.packet_counter - 1L, bool);
/*  94 */       this.packet_counter++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadProperties() throws SocketException {
/*     */     try {
/* 109 */       Properties properties = new Properties();
/* 110 */       properties.load(new FileInputStream(PROP));
/*     */       
/* 112 */       String[] arrayOfString = properties.getProperty("packet.droprate", "0").split(",");
/*     */       
/* 114 */       if (arrayOfString.length == 1) {
/* 115 */         this.packet_droprate = Float.parseFloat(arrayOfString[0]);
/*     */       } else {
/*     */         
/* 118 */         this.packet_drop = new int[arrayOfString.length];
/* 119 */         for (byte b = 0; b < arrayOfString.length; b++) {
/* 120 */           this.packet_drop[b] = Integer.parseInt(arrayOfString[b]);
/*     */         }
/*     */       } 
/* 123 */       this.packet_delay_min = Integer.parseInt(properties.getProperty("packet.delay.minimum", "0"));
/* 124 */       this.packet_delay_max = Integer.parseInt(properties.getProperty("packet.delay.maximum", "0"));
/* 125 */       this.packet_mtu = Integer.parseInt(properties.getProperty("packet.mtu", "1500"));
/* 126 */       this.packet_mtu = (this.packet_mtu <= 0) ? Integer.MAX_VALUE : this.packet_mtu;
/*     */       
/* 128 */       if (Boolean.parseBoolean(properties.getProperty("log.enable", "true"))) {
/* 129 */         logger = properties.getProperty("log.filename", "system").equalsIgnoreCase("system") ? System.out : new PrintStream(properties.getProperty("log.filename"));
/*     */       
/*     */       }
/*     */     }
/* 133 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private class senderThread
/*     */     extends Thread
/*     */   {
/*     */     UDPSocket socket;
/*     */     
/*     */     DatagramPacket packet;
/*     */     long id;
/*     */     boolean drop;
/*     */     
/*     */     senderThread(UDPSocket param1UDPSocket1, DatagramPacket param1DatagramPacket, long param1Long, boolean param1Boolean) {
/* 147 */       this.socket = param1UDPSocket1;
/* 148 */       this.packet = new DatagramPacket(param1DatagramPacket.getData(), param1DatagramPacket.getLength(), param1DatagramPacket.getAddress(), param1DatagramPacket.getPort());
/* 149 */       this.id = param1Long;
/* 150 */       this.drop = param1Boolean;
/* 151 */       start();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() throws SocketException {
/*     */       try {
/* 158 */         sleep((long)(UDPSocket.this.packet_delay_min + UDPSocket.this.rand.nextFloat() * (UDPSocket.this.packet_delay_max - UDPSocket.this.packet_delay_min)));
/*     */         
/*     */         try {
/* 161 */           if (!this.drop) this.socket.rawSend(this.packet); 
/* 162 */           UDPSocket.log(this.packet, this.id, this.drop);
/*     */         }
/* 164 */         catch (Exception exception) {
/*     */           
/* 166 */           exception.printStackTrace();
/*     */         }
/*     */       
/* 169 */       } catch (InterruptedException interruptedException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void log(DatagramPacket paramDatagramPacket, long paramLong, boolean paramBoolean) {
/* 177 */     if (logger == null)
/*     */       return; 
/* 179 */     logger.print(Format.sprintf("%-5d  %5d %s:%s %s ", (new Parameters(System.currentTimeMillis() - start_time)).add(paramLong).add(paramDatagramPacket.getAddress().getHostAddress()).add(paramDatagramPacket.getPort()).add(paramBoolean ? "XXX" : "-->")));
/*     */     
/*     */     byte b;
/* 182 */     for (b = 0; b < paramDatagramPacket.getLength(); b++)
/* 183 */       logger.print(toChar(paramDatagramPacket.getData()[b])); 
/* 184 */     logger.print(" :: ");
/* 185 */     for (b = 0; b < paramDatagramPacket.getLength(); b++)
/* 186 */       logger.print(Format.sprintf("%02X ", new Parameters(paramDatagramPacket.getData()[b]))); 
/* 187 */     logger.println();
/*     */   }
/*     */ 
/*     */   
/*     */   private static char toChar(byte paramByte) {
/* 192 */     char c = (char)(paramByte & 0xFF);
/* 193 */     if (c <= '' && !Character.isISOControl(c)) {
/* 194 */       return c;
/*     */     }
/* 196 */     return '.';
/*     */   }
/*     */ }


/* Location:              C:\Users\Syvirx\OneDrive - University of Tulsa\CS Labs\Networks\src\!\ed\\utuls\\unet\UDPSocket.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */