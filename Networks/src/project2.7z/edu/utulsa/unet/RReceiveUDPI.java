package edu.utulsa.unet;

public interface RReceiveUDPI {
  boolean setMode(int paramInt);
  
  int getMode();
  
  boolean setModeParameter(long paramLong);
  
  long getModeParameter();
  
  void setFilename(String paramString);
  
  String getFilename();
  
  boolean setLocalPort(int paramInt);
  
  int getLocalPort();
  
  boolean receiveFile();
}


/* Location:              C:\Users\Syvirx\OneDrive - University of Tulsa\CS Labs\Networks\src\!\ed\\utuls\\unet\RReceiveUDPI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */